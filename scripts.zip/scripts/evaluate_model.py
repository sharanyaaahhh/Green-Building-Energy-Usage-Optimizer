import pandas as pd
import joblib
from sklearn.metrics import mean_squared_error

# Load test data
df = pd.read_csv("data/processed/test.csv")
X_test = df.drop(columns=["meter_reading"])
y_test = df["meter_reading"]

# Load model
model = joblib.load("app/models/lightgbm_model.pkl")

# Predict and evaluate
y_pred = model.predict(X_test)
rmse = mean_squared_error(y_test, y_pred, squared=False)
print(f"RMSE: {rmse:.2f}")