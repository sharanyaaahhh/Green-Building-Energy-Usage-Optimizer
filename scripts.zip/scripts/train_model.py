import pandas as pd
import lightgbm as lgb
import joblib
import os

# Load and merge data
train_df = pd.read_csv("data/raw/train.csv")
weather_df = pd.read_csv("data/raw/weather_train.csv")
meta_df = pd.read_csv("data/raw/building_metadata.csv")

print("train_df columns:", train_df.columns.tolist())
print("weather_df columns:", weather_df.columns.tolist())

# 🔁 First merge train_df with meta_df to get site_id
train_df = train_df.merge(meta_df, on="building_id")

# ✅ Now merge with weather_df using site_id and timestamp
df = train_df.merge(weather_df, on=["site_id", "timestamp"])


# Feature engineering
df["hour"] = pd.to_datetime(df["timestamp"]).dt.hour
df["day"] = pd.to_datetime(df["timestamp"]).dt.day
df["month"] = pd.to_datetime(df["timestamp"]).dt.month

features = [
    "square_feet", "year_built", "air_temperature", "dew_temperature",
    "cloud_coverage", "precip_depth_1_hr", "hour", "day", "month"
]
target = "meter_reading"

X = df[features].fillna(0)
y = df[target]

# Train model
model = lgb.LGBMRegressor()
model.fit(X, y)

# Save model
os.makedirs("app/models", exist_ok=True)
joblib.dump(model, "app/models/lightgbm_model.pkl")