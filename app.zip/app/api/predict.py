from fastapi import APIRouter
from app.schemas.request import HouseInput
from app.services.predictor import run_prediction

router = APIRouter()

@router.post("/")
def predict(data: HouseInput):
    return run_prediction(data)