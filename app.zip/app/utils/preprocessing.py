from app.schemas.request import BuildingParams

def build_feature_vector(params: BuildingParams):
    return [
        params.square_feet,
        params.year_built,
        params.air_temperature,
        params.dew_temperature,
        params.cloud_coverage,
        params.precip_depth_1_hr,
        params.hour,
        params.day,
        params.month
    ]