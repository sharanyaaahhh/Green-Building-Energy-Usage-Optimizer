from pydantic import BaseModel
from typing import List, Optional

class RoomData(BaseModel):
    type: str
    size: int
    windows: Optional[int] = 0
    usage: Optional[str] = "medium"

class HouseInput(BaseModel):
    squareFootage: int
    bedrooms: int
    houseAge: str
    insulation: str
    heating: str
    cooling: str
    waterHeater: str
    lighting: str
    rooms: List[RoomData]