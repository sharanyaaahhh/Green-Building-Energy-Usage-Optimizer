from fastapi import FastAPI
from app.api import predict

app = FastAPI(title="Green Building Energy Optimizer")

app.include_router(predict.router, prefix="/predict", tags=["Prediction"])
from fastapi.middleware.cors import CORSMiddleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)