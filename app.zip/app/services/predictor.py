from app.schemas.request import HouseInput
from typing import Dict, List

def run_prediction(data: HouseInput) -> Dict:
    sqft = data.squareFootage
    base_kwh = sqft * 12

    age_factor = {
        "new": 0.85,
        "recent": 1.0,
        "older": 1.2,
        "vintage": 1.4
    }.get(data.houseAge, 1.0)

    insulation_factor = {
        "excellent": 0.8,
        "good": 0.9,
        "average": 1.0,
        "poor": 1.3
    }.get(data.insulation, 1.0)

    heating_eff = {
        "heat-pump": 0.7,
        "gas": 0.85,
        "electric": 1.0,
        "oil": 1.2,
        "solar": 0.3
    }.get(data.heating, 1.0)

    cooling_eff = {
        "heat-pump": 0.7,
        "central-ac": 1.0,
        "window-units": 1.2,
        "evaporative": 0.6,
        "none": 0
    }.get(data.cooling, 1.0)

    water_eff = {
        "heat-pump": 0.6,
        "tankless": 0.8,
        "gas-tank": 0.9,
        "electric-tank": 1.0,
        "solar": 0.2
    }.get(data.waterHeater, 1.0)

    lighting_eff = {
        "led": 0.25,
        "cfl": 0.5,
        "halogen": 0.9,
        "incandescent": 1.0
    }.get(data.lighting, 1.0)

    current_kwh = base_kwh * age_factor * insulation_factor
    current_kwh += current_kwh * 0.4 * heating_eff
    current_kwh += current_kwh * 0.25 * cooling_eff
    current_kwh += current_kwh * 0.15 * water_eff
    current_kwh += current_kwh * 0.1 * lighting_eff
    current_kwh += current_kwh * 0.1  # other appliances

    projected_kwh = current_kwh

    if data.lighting in ["incandescent", "halogen"]:
        projected_kwh -= base_kwh * 0.1 * 0.75

    if data.heating in ["electric", "oil"]:
        projected_kwh -= base_kwh * 0.4 * 0.4

    if data.insulation in ["poor", "average"]:
        projected_kwh *= 0.85

    if data.waterHeater in ["electric-tank", "gas-tank"]:
        projected_kwh -= base_kwh * 0.15 * 0.3

    projected_kwh *= 0.88  # smart thermostat
    solar_offset = current_kwh * 0.8
    with_solar = projected_kwh - solar_offset

    recommendations = []

    if data.lighting in ["incandescent", "halogen"]:
        recommendations.append({
            "title": "Switch to LED Lighting",
            "description": "Replace inefficient bulbs with LEDs to cut lighting energy by 75%.",
            "savings": "$75-150/year",
            "energySavings": "75% lighting energy reduction",
            "priority": "High",
            "category": "Lighting",
            "icon": "💡"
        })

    if data.heating in ["electric", "oil"]:
        recommendations.append({
            "title": "Upgrade to Heat Pump",
            "description": "Install a heat pump for efficient heating and cooling.",
            "savings": "$400-800/year",
            "energySavings": "40% heating energy reduction",
            "priority": "High",
            "category": "HVAC",
            "icon": "🌡️"
        })

    if data.insulation in ["poor", "average"]:
        recommendations.append({
            "title": "Improve Insulation",
            "description": "Upgrade insulation to reduce heat loss and improve efficiency.",
            "savings": "$200-500/year",
            "energySavings": "15% overall energy reduction",
            "priority": "High",
            "category": "Insulation",
            "icon": "🏠"
        })

    if data.waterHeater in ["electric-tank", "gas-tank"]:
        recommendations.append({
            "title": "Install Tankless Water Heater",
            "description": "Switch to tankless or heat pump water heater for better efficiency.",
            "savings": "$100-300/year",
            "energySavings": "30% water heating energy reduction",
            "priority": "Medium",
            "category": "Water Heating",
            "icon": "🚿"
        })

    recommendations.append({
        "title": "Smart Thermostat",
        "description": "Install a smart thermostat to optimize HVAC schedules.",
        "savings": "$100-200/year",
        "energySavings": "12% HVAC energy reduction",
        "priority": "Medium",
        "category": "Smart Home",
        "icon": "📱"
    })

    recommendations.append({
        "title": "Solar Panel System",
        "description": "Install rooftop solar panels to offset electricity usage.",
        "savings": "$800-1500/year",
        "energySavings": "70-90% electricity offset",
        "priority": "Long-term",
        "category": "Renewable Energy",
        "icon": "☀️"
    })

    return {
        "energy": {
            "current": round(current_kwh),
            "projected": round(projected_kwh),
            "withSolar": round(with_solar),
            "solarOffset": round(solar_offset)
        },
        "recommendations": recommendations
    }