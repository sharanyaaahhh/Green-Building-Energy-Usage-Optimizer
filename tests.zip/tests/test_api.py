from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_prediction():
    payload = {
        "square_feet": 2500,
        "year_built": 2012,
        "air_temperature": 28.5,
        "dew_temperature": 20.0,
        "cloud_coverage": 2,
        "precip_depth_1_hr": 0.1,
        "hour": 14,
        "day": 20,
        "month": 8
    }
    response = client.post("/predict/", json=payload)
    assert response.status_code == 200
    assert "predicted_meter_reading" in response.json()